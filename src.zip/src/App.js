/**
 * React frontend for Algo Chatbot
 * this component renders a simple chat UI where users can type messages,
 * send them to FastAPI backend, and display bot responses
 */


import { useLayoutEffect, useRef, useState } from "react";

function App() {
    //state to hold the conversation
  const [messages, setMessages] = useState([]);
  // state to hold the current input from the user
  const [input, setInput] = useState("");
  //ref to scroll into view
  const chatEndRef = useRef(null);

  useLayoutEffect(() => {
    console.log("Auto-scrolling...");
    chatEndRef.current?.scrollIntoView({behavior: "smooth"});
  }, [messages]);

    /**
     * Handles sending a message to backend.
     * 1. Adds the user's message to chat history.
     * 2. Sends a POST request to FastAPI
     * 3. Adds the bot's repy to chat history
     */
  const sendMessage = async () => {
    // Prevent sending empty messages
    if (!input.trim()) return;
    console.log("Sending message", input);

    try {
        // Send the message to FastAPI backend
        // Proxy is set in package.json, so we can use relative path api/message
      const response = await fetch("/api/message", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: input }),
      });
      // parse the JSON reply
      const data = await response.json();

      // Add bot reply to chat history
    setMessages((prev) => [
        ...prev,
        { sender: "You", text: input },
        { sender: "Bot", text: data.reply}
    ]);

    } catch (err) {
        // handle network or server errors gracefully
      setMessages((prev) => [
        ...prev, 
        { sender: "You", text: input },
        { sender: "Bot", text: "Error: " + err.message}
    ]);
    }
    // clear the input box after sending
    setInput("");
  };

  return (
    <div
      style={{
        maxWidth: "600px",
        margin: "40px auto",
        fontFamily: "Arial, sans-serif",
      }}
    >
      <h2 style={{ textAlign: "center" }}>Algo Chatbot</h2>

      {/* Chat container */}
      <div
        style={{
          border: "1px solid #ccc",
          padding: "10px",
          height: "400px",
          overflowY: "auto",
          backgroundColor: "#f9f9f9",
        }}
      >
        {messages.map((msg, idx) => (
          <div
            key={idx}
            style={{
              display: "flex",
              justifyContent:
                msg.sender === "You" ? "flex-end" : "flex-start",
              margin: "5px 0",
            }}
          >
            <div
              style={{
                padding: "10px",
                borderRadius: "15px",
                maxWidth: "70%",
                backgroundColor:
                  msg.sender === "You" ? "#007bff" : "#e5e5ea",
                color: msg.sender === "You" ? "white" : "black",
              }}
            >
              {msg.text}
            </div>
          </div>
        ))}
        {/* Anchor element to auto-scroll into view */}
        <div ref={chatEndRef} />
      </div>

      {/* Input box */}
      <div style={{ marginTop: "10px", display: "flex" }}>
        <input
          style={{
            flex: 1,
            padding: "10px",
            borderRadius: "5px",
            border: "1px solid #ccc",
          }}
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Type a message..."
          onKeyPress={(e) => e.key === "Enter" && sendMessage()}
        />
        <button
          onClick={sendMessage}
          style={{
            marginLeft: "10px",
            padding: "10px 20px",
            border: "none",
            borderRadius: "5px",
            backgroundColor: "#007bff",
            color: "white",
            cursor: "pointer",
          }}
        >
          Send
        </button>
      </div>
    </div>
  );
}

export default App;
